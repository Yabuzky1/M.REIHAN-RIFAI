package koneksi;
import java.sql.Connecction;
import java.sql.DriverManager;
import java.sql.Statement;
public class KoneksiDatabase {
    pubic static Connection aam;
    pubic static Statement atm;
        public 
}